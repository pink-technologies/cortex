// Copyright (c) 2026, PinkTech
// https://pink-tech.io/

import type { AgentDescriptor } from '@/definitions/models/agent-definition/agent-definition'
import { CapabilityInputSchema } from '@/capabilities/schema/input/capability-input.schema'
import { ConversationMessage } from '@/shared/types/input/execution-input'

/**
 * High-level persona / responsibility label for an agent.
 *
 * Used in {@link AgentDescriptor.role} and for UX or routing hints (not a security boundary by itself).
 *
 * @property Assistant — General assistant behavior.
 * @property Specialist — Focused domain or task specialist.
 */
export const AgentRole = {
  Main: 'main',
  Specialist: 'specialist',
} as const;

/** Union of string literals in {@link AgentRole}. */
export type AgentRole = (typeof AgentRole)[keyof typeof AgentRole];

/**
 * Discriminator values for {@link AgentDecision}.
 *
 * @property Delegate — Hand off to another agent by id.
 * @property Respond — Plain-text reply (no further agent hop in this step).
 * @property SuggestCapability — Suggest a capability to the user.
 * @property SuggestSkill — Suggest a skill to the user.
 * @property SuggestOptions — Suggest both capabilities and skills in one turn (mixed discovery / orientation).
 * @property UseCapability — Invoke a registered capability with structured input.
 * @property UseSkill — Invoke a registered skill with structured input.
 */
export const AgentDecisionType = {
  Delegate: 'delegate',
  Respond: 'respond',
  SuggestCapability: 'suggest-capability',
  SuggestSkill: 'suggest-skill',
  SuggestOptions: 'suggest-options',
  UseCapability: 'use-capability',
  UseSkill: 'use-skill',
} as const;

/** Union of string literals in {@link AgentDecisionType}. */
export type AgentDecisionType = (typeof AgentDecisionType)[keyof typeof AgentDecisionType];

/**
 * Represents the next action selected by an agent for a single execution turn.
 *
 * `AgentDecision` is a discriminated union. The `type` field determines which
 * action the runtime should perform next, such as delegating to another agent,
 * responding directly to the user, suggesting available actions, or invoking a
 * skill or capability.
 *
 * Agent decisions are produced by executable agents and interpreted by the
 * kernel or orchestrator. The agent describes what should happen, while the
 * runtime remains responsible for enforcing safety rules, executing skills and
 * capabilities, handling delegation depth, and returning final responses.
 */
export type AgentDecision =
  /**
   * Delegates the current task to another agent.
   *
   * The target agent is resolved using `agentId`. The optional `reason` explains
   * why delegation is appropriate and can be used for tracing, debugging, or
   * audit logs.
   */
  | {
      readonly type: typeof AgentDecisionType.Delegate;
      readonly agentId: string;
      readonly reason?: string;
    }

  /**
   * Returns a direct response to the user.
   *
   * This decision ends the current turn with a user-facing message.
   */
  | {
      readonly type: typeof AgentDecisionType.Respond;
      readonly response: string;
    }

  /**
   * Suggests one or more capabilities that may help satisfy the request.
   *
   * This decision is useful when the agent identifies relevant capabilities but
   * should not invoke them directly, usually because user confirmation, missing
   * input, or policy approval is required.
   */
  | {
      readonly type: typeof AgentDecisionType.SuggestCapability;
      readonly message: string;
      readonly capabilities: CapabilityInputSchema[];
    }

  /**
   * Suggests one or more skills that may help satisfy the request.
   *
   * This decision is useful when the agent identifies relevant skills but should
   * not execute them directly, usually because user confirmation, missing input,
   * or policy approval is required.
   */
  | {
      readonly type: typeof AgentDecisionType.SuggestSkill;
      readonly message: string;
     // readonly skills: SkillInputSchema[];
    }

  /**
   * Suggests a combined set of capabilities and skills.
   *
   * This decision is useful when the agent can offer multiple possible execution
   * paths and the user or runtime should choose which action to take.
   */
  | {
      readonly type: typeof AgentDecisionType.SuggestOptions;
      readonly message: string;
      readonly capabilities: CapabilityInputSchema[];
      //readonly skills: SkillInputSchema[];
    }

  /**
   * Requests execution of a capability.
   *
   * Capabilities usually represent integration-backed operations or tool
   * bundles. The runtime is responsible for validating access, enforcing safety
   * policy, resolving the capability implementation, and executing it with the
   * provided input.
   */
  | {
      readonly type: typeof AgentDecisionType.UseCapability;
      readonly capabilityId: string;
      readonly input: Record<string, unknown>;
      readonly userMessage: string;
    }

  /**
   * Requests execution of a skill.
   *
   * Skills represent structured workflows or reasoning behaviors available to
   * the agent. The runtime is responsible for validating access, resolving the
   * skill implementation, and executing it with the provided input.
   */
  | {
      readonly type: typeof AgentDecisionType.UseSkill;
      readonly skillId: string;
      readonly input: Record<string, unknown>;
    };

/**
 * Per-turn input to {@link AgentDefinition.decide}: correlates with a single user message within a run.
 *
 * Aligns conceptually with shared {@link ExecutionContext} fields where the kernel passes
 * execution id and message into the agent layer.
 */
export interface AgentContext {
  /**
   * Correlates logs, tool calls, and nested hops for this execution (e.g. UUID/ULID).
   */
  readonly executionId: string;

  /**
   * Normalized user utterance for this decision step.
   */
  readonly message: string;

  /**
   * Full thread for LLM replay (same shape as {@link ConversationMessage}).
   */
  readonly conversationHistory?: readonly ConversationMessage[];
}


/**
 * Represents an agent capable of deciding how to handle a request.
 *
 * An [Agent] receives an {@link AgentContext} and returns one or more
 * {@link AgentDecision} values that describe the next actions to execute,
 * such as responding directly, using a skill, using a capability, or
 * delegating to another agent.
 */
export interface Agent {
  /**
   * Stable key used to register and resolve the agent.
   *
   * The identifier is used by {@link AgentRegistry} and by 
   * delegation decisions in {@link AgentDecision}.
   */
  readonly id: string

  /**
   * Static catalog descriptor (capabilities, skills, prompt, role).
   */
  readonly descriptor: AgentDescriptor

  /**
   * Decides how to handle the current agent context.
   *
   * @param context - Context available to the agent for the current execution.
   * @returns The decisions produced by the agent.
   */
  decide(context: AgentContext): Promise<AgentDecision[]>;
}