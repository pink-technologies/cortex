// Copyright (c) 2026, PinkTech
// https://pink-tech.io/

/**
 * Base class for errors raised by the agent domain.
 *
 * [AgentError] provides a shared structure for agent-related failures,
 * including a machine-readable error code and an optional underlying cause
 * for diagnostics.
 */
export abstract class AgentError extends Error {
  // MARK: - Properties

  /**
   * A machine-readable error code identifying the type of
   * agent service error.
   */
  abstract readonly code: string;

  /**
   * The underlying error that originated this domain error.
   *
   * This value is intended for diagnostics, logging, and debugging,
   * and should generally not be exposed directly to consumers.
   */
  readonly cause?: ErrorOptions;

  // MARK: - Initializer

  /**
   * Creates a new {@link AgentServiceError} instance.
   *
   * - Parameter message: A human-readable description of the failure.
   * @param options - Optional error details, including the original cause.
   */
  protected constructor(message: string, cause?: ErrorOptions) {
    super(message);

    this.cause = cause;
  }
}

/**
 * Error thrown when an agent cannot generate valid decisions.
 *
 * This usually happens when the language model returns an empty response,
 * malformed JSON, or data that does not match the expected
 * {@link AgentDecision} schema.
 */
export class FailedToGenerateDecisionsError extends AgentError {
  // MARK: - Properties

  /**
   * Machine-readable code for duplicate agent id registration errors.
   */
  readonly code = 'FAILED_TO_GENERATE_DECISIONS_ERROR';

  // MARK: - Constructor

  constructor(options?: ErrorOptions) {
    super(`Failed to generate decisions`, options);
    this.name = new.target.name;
  }
}
