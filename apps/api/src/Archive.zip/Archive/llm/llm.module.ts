// Copyright (c) 2026, PinkTech
// https://pink-tech.io/

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

// TODO: Configuration Key for LLM is wrong here - need to fix it
// The model should be loaded and registered with their configurations
// Stored
@Module({
  imports: [ConfigModule],
})
export class LLMModule {}
