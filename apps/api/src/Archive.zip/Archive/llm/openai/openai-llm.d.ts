import type { LLM, LLMMessage, LLMOptions, LLMResponse, StreamEvent } from 'apps/api/src/llm/llm';
import { LLMModel } from '../provider/llm-provider';
export declare class OpenAILLM implements LLM {
    private readonly client;
    readonly supportedModels: LLMModel[];
    constructor(apiKey: string);
    chat(messages: LLMMessage[], options: LLMOptions): Promise<LLMResponse>;
    stream(messages: LLMMessage[], options: LLMOptions): AsyncIterable<StreamEvent>;
}
