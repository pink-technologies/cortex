import { ChatCompletion, ChatCompletionMessageParam, ChatCompletionTool } from 'openai/resources';
import { LLMError } from 'apps/api/src/llm/error/error';
import { LLMMessage, type LLMResponse, LLMToolDefinition } from 'apps/api/src/llm/llm';
export declare function mapFromOpenAIChatCompletion(chatCompletion: ChatCompletion): LLMResponse;
export declare function mapFromOpenAIError(error: unknown): LLMError;
export declare function mapToOpenAIMessages(messages: LLMMessage[]): ChatCompletionMessageParam[];
export declare function mapToOpenAIMessageList(messages: LLMMessage[], systemPrompt: string | undefined): ChatCompletionMessageParam[];
export declare function mapToOpenAITool(tool: LLMToolDefinition): ChatCompletionTool;
