import { LLM } from '../llm';
export type LLMModel = string;
export declare const LLMProviderType: {
    readonly anthropic: "anthropic";
    readonly openAI: "apenAI";
};
export type LLMProviderType = (typeof LLMProviderType)[keyof typeof LLMProviderType];
export type LLMOptions = {
    apiKey: string;
};
export interface LLMFactory {
    create(type: LLMProviderType, options: LLMOptions): LLM;
}
export declare class LLMFactoryImpl implements LLMFactory {
    create(type: LLMProviderType, options: LLMOptions): LLM;
}
