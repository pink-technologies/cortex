// Copyright (c) 2026, PinkTech
// https://pink-tech.io/

import { LLM } from '../llm';
import { OpenAILLM } from '../openai/openai-llm';

export type LLMModel = string

export const LLMProviderType = {
  anthropic: 'anthropic',
  openAI: 'apenAI',
} as const

export type LLMProviderType = (typeof LLMProviderType)[keyof typeof LLMProviderType]

export type LLMOptions = {  
  apiKey: string,
}

export interface LLMFactory {
  create(type: LLMProviderType, options: LLMOptions): LLM
}

export class LLMFactoryImpl implements LLMFactory {
  // MARK: - LLMFactory

  create(type: LLMProviderType, options: LLMOptions): LLM {
    switch (type) {
      case LLMProviderType.openAI:
        return new OpenAILLM(options.apiKey)

      default:
        throw new Error(`Unsupported provider: ${type}`)
    }
  }
}
